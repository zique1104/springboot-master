/**
 * 
 */
/**
 * @ClassName package-info
 * @Description TODO
 * @author lide
 * @date 2018年2月9日 下午4:22:34
 */
package com.example.game.domain.pojo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

public class TestPojo{
	private String name;
	private Integer age;
	private String sex;
}