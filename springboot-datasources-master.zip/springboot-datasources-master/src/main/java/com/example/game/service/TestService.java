package com.example.game.service;

public interface TestService {

	Integer queryCountByMester();
	
	Integer queryCountBySavle();
	
}
